#Scroll Events

Grâce à l'événement scroll, on peut savoir combien de pixels ont déjà disparu au sommet de l'écran.

Du coup, ça permet d'en profiter pour faire le malin.

Par exemple, mettre un titre.

#Un Titre

Puis, on peut afficher la position (comme dans l'exemple simple.html), mais ça ne sert à rien, en général.

Du coup, on devrait s'en servir pour faire totalement autre chose, comme faire avancer une histoire, scroller horizontalement par esprit de contradiction, ou faire des prouts comme avec FartScroll.js.

Bref, qu'est-ce qu'on s'amuse

#oui

-------------

_From the [DWM](http://dwm.re) team - [@pixeline](https://twitter.com/pixeline) [@boblemarin](https://twitter.com/boblemarin) [@lelipelip](https://twitter.com/lelipelip) [@aqro](https://twitter.com/aqro) [@remysaintcricq](https://twitter.com/remysaintcricq) [@fbourgaux](https://twitter.com/fbourgaux) [@chdelfosse](https://twitter.com/chdelfosse) [@teddytdk](https://twitter.com/teddytdk)_
