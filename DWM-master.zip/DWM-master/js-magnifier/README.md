#Tu veux faire une loupe ou un truc spécial qu'on peut regarder à travers un truc qui bouge ?

Ben voilà, tu es au bon endroit.

#Le concept

Déplacer un élément (<div>) avec la souris, tout en déplaçant l'image de fond de cet élément dans la direction opposée.

Au final, ça donne un effet saisissant qu'on dirait totalement autre chose.

C'est vraiment super beau.

Tu devrais essayer, donc.

#Pré-requis

rien.

#Post-requis

Faire une petite pose.

