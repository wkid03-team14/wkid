#DWM - Tips&Tricks

Pour faire une animation avec un sprite, il suffit de faire les frames(steps) de la m�me largeure et ensuite d'utiliser le code css pour les afficher un a un.
Ne pas oublier de changer le nombre de frames(steps).


-------------

_From the [DWM](http://dwm.re) team - [@pixeline](https://twitter.com/pixeline) [@boblemarin](https://twitter.com/boblemarin) [@lelipelip](https://twitter.com/lelipelip) [@aqro](https://twitter.com/aqro) [@remysaintcricq](https://twitter.com/remysaintcricq) [@fbourgaux](https://twitter.com/fbourgaux) [@chdelfosse](https://twitter.com/chdelfosse) [@teddytdk](https://twitter.com/teddytdk)_
